#ifndef CAIAQ_CONTROL_H
#define CAIAQ_CONTROL_H

int snd_usb_caiaq_control_init(struct snd_usb_caiaqdev *dev);

#endif /* CAIAQ_CONTROL_H */
