#ifndef USX2YHWDEP_H
#define USX2YHWDEP_H

int usX2Y_hwdep_new(struct snd_card *card, struct usb_device* device);

#endif
